package persona;

//  Clase base Persona
public class Persona {
    protected String dni;
    protected String nombres;
    protected String apellidos;

    public Persona(String dni, String nombres, String apellidos) {
        this.dni = dni;
        this.nombres = nombres;
        this.apellidos = apellidos;
    }

    public String getDni() { return dni; }
    public String getNombres() { return nombres; }
    public String getApellidos() { return apellidos; }

    public String getFullName() {
        return nombres + " " + apellidos;
    }

    @Override
    public String toString() {
        return getFullName() + " (DNI: " + dni + ")";
    }
}