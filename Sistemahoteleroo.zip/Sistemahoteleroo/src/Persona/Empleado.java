package persona;

//  Subclase Empleado
public class Empleado extends Persona {
    private final String rol;      // ADMIN o RECEP
    private final String password; 

    public Empleado(String dni, String nombres, String apellidos, String rol, String password) {
        super(dni, nombres, apellidos);
        this.rol = rol;
        this.password = password;
    }

    public String getRol() { return rol; }
    public boolean checkPassword(String p) { return password != null && password.equals(p); }

    @Override
    public String toString() {
        return super.toString() + " - Rol: " + rol;
    }
}