package persona;

//  Subclase Cliente (Huésped)
public class Cliente extends Persona {
    private final String contacto;

    public Cliente(String dni, String nombres, String apellidos, String contacto) {
        super(dni, nombres, apellidos);
        this.contacto = contacto;
    }

    public String getContacto() { return contacto; }

    @Override
    public String toString() {
        return super.toString() + " - Contacto: " + contacto;
    }
}