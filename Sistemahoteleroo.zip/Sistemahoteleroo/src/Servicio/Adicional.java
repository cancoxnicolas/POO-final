package servicio;

public class Adicional extends Servicio {
    public Adicional(String nombre, double precio) {
        super(nombre, precio);
    }
}