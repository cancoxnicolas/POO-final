package servicio;

public class Obligatorio extends Servicio {
    // Campos para habitación (opcional)
    private boolean isRoom;
    private int numero;
    private int capacidad;
    private String tipo;   // Simple, Doble, Suite
    private String estado; // Limpia, Ocupada, Sucia

    // Constructor genérico (no-room)
    public Obligatorio(String nombre, double precio) {
        super(nombre, precio);
        this.isRoom = false;
    }

    // Constructor para habitación
    public Obligatorio(int numero, int capacidad, double precio, String tipo) {
        super("Habitación " + numero + " (" + tipo + ")", precio);
        this.isRoom = true;
        this.numero = numero;
        this.capacidad = capacidad;
        this.tipo = tipo;
        this.estado = "Limpia";
    }

    // Métodos habitación
    public boolean isRoom() { return isRoom; }
    public int getNumero() { return numero; }
    public int getCapacidad() { return capacidad; }
    public String getTipo() { return tipo; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public String toString() {
        if (isRoom) {
            return String.format("Hab %d | Tipo: %s | Cap: %d | Precio: S/.%.2f | Estado: %s",
                    numero, tipo, capacidad, precio, estado);
        } else {
            return super.toString();
        }
    }
}