package hotel;

import persona.Cliente;
import persona.Empleado;
import servicio.Adicional;
import servicio.Obligatorio;
import servicio.Servicio;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * Controller (package hotel)
 * Centraliza los datos en memoria y expone métodos utilizados por las GUIs.
 *
 * - Campos públicos para facilitar acceso desde las GUIs (puedes encapsular con getters si prefieres).
 * - Métodos públicos para crear/listar/operar reservas, estadías y consumos.
 */
public class Controller {

    // Repositorios públicos (las GUIs acceden directamente en ejemplos; puedes cambiar a private/getters)
    public final List<Empleado> empleados = new ArrayList<>();
    public final List<Cliente> clientes = new ArrayList<>();
    public final List<Obligatorio> habitaciones = new ArrayList<>();
    public final List<Adicional> serviciosAdicionales = new ArrayList<>();

    // Internos del dominio
    private final List<Reservacion> reservaciones = new ArrayList<>();
    private final List<Estadia> estadias = new ArrayList<>();
    private final List<Factura> facturas = new ArrayList<>();

    private int nextReservaId = 1000;

    public Controller() {
        seed();
    }

    // ---------------- seed datos de prueba ----------------
    private void seed() {
        // Empleados
        empleados.add(new Empleado("11111111", "Admin", "Sistema", "ADMIN", "admin"));
        empleados.add(new Empleado("22222222", "Rosa", "Recep", "RECEP", "recep"));

        // Habitaciones (Obligatorio representa habitaciones)
        habitaciones.add(new Obligatorio(101, 2, 120.0, "Simple"));
        habitaciones.add(new Obligatorio(102, 2, 160.0, "Doble"));
        habitaciones.add(new Obligatorio(201, 4, 260.0, "Suite"));

        // Servicios adicionales
        serviciosAdicionales.add(new Adicional("Lavandería", 15.0));
        serviciosAdicionales.add(new Adicional("Servicio a la habitación", 25.0));
        serviciosAdicionales.add(new Adicional("Frigobar", 10.0));

        // Clientes
        clientes.add(new Cliente("33333333", "Ana", "Vargas", "999999999"));
        clientes.add(new Cliente("44444444", "Luis", "Gomez", "988888888"));
    }

    // -------------------- AUTENTICACIÓN --------------------
    public Empleado login(String dni, String pwd) {
        for (Empleado e : empleados) {
            if (e.getDni().equals(dni) && e.checkPassword(pwd)) return e;
        }
        return null;
    }

    // -------------------- CLIENTES --------------------
    public Cliente crearCliente(String dni, String nombres, String apellidos, String contacto) {
        Cliente c = new Cliente(dni, nombres, apellidos, contacto);
        clientes.add(c);
        return c;
    }

    public List<Cliente> listarClientes() {
        return new ArrayList<>(clientes);
    }

    public boolean eliminarCliente(String dni) {
        return clientes.removeIf(c -> c.getDni().equals(dni));
    }

    // -------------------- EMPLEADOS --------------------
    public void crearEmpleado(String dni, String nombres, String apellidos, String rol, String pwd) {
        empleados.add(new Empleado(dni, nombres, apellidos, rol, pwd));
    }

    public List<Empleado> listarEmpleados() {
        return new ArrayList<>(empleados);
    }

    public boolean eliminarEmpleado(String dni) {
        return empleados.removeIf(e -> e.getDni().equals(dni));
    }

    // -------------------- HABITACIONES --------------------
    public Obligatorio crearHabitacion(int numero, int capacidad, double precio, String tipo) {
        Obligatorio h = new Obligatorio(numero, capacidad, precio, tipo);
        habitaciones.add(h);
        return h;
    }

    public String listarHabitaciones() {
        StringBuilder sb = new StringBuilder();
        for (Obligatorio h : habitaciones) {
            if (h.isRoom()) sb.append(h).append("\n");
        }
        return sb.toString();
    }

    public List<Obligatorio> listarHabitacionesList() {
        return new ArrayList<>(habitaciones);
    }

    public boolean eliminarHabitacion(int numero) {
        return habitaciones.removeIf(h -> h.isRoom() && h.getNumero() == numero);
    }

    // -------------------- SERVICIOS ADICIONALES --------------------
    public Adicional crearServicioAdicional(String nombre, double precio) {
        Adicional a = new Adicional(nombre, precio);
        serviciosAdicionales.add(a);
        return a;
    }

    public String listarServiciosStr() {
        StringBuilder sb = new StringBuilder();
        for (Adicional a : serviciosAdicionales) sb.append(a).append("\n");
        return sb.toString();
    }

    public List<Adicional> listarServiciosList() {
        return new ArrayList<>(serviciosAdicionales);
    }

    public boolean eliminarServicioAdicional(String nombre) {
        return serviciosAdicionales.removeIf(s -> s.getNombre().equalsIgnoreCase(nombre));
    }

    // -------------------- RESERVAS / ESTADIAS / CONSUMOS --------------------
    // Internal domain classes
    private static class Reservacion {
        static int NEXT = 1000;
        int id;
        Cliente cliente;
        LocalDate desde;
        LocalDate hasta;
        String tipoHabitacion;
        Obligatorio habitacionAsignada;
        boolean active = true;

        Reservacion(Cliente c, LocalDate desde, LocalDate hasta, String tipo) {
            this.id = NEXT++;
            this.cliente = c;
            this.desde = desde;
            this.hasta = hasta;
            this.tipoHabitacion = tipo;
            this.habitacionAsignada = null;
        }

        void asignarHabitacion(Obligatorio h) { this.habitacionAsignada = h; }
        void cancelar() { this.active = false; }
    }

    private static class Consumo {
        Adicional servicio;
        int cantidad;
        Consumo(Adicional s, int q) { servicio = s; cantidad = q; }
        double subtotal() { return servicio.getPrecio() * cantidad; }
    }

    private static class Estadia {
        Reservacion reservacion;
        Obligatorio habitacion;
        LocalDate checkIn;
        LocalDate checkOut; // null hasta checkout
        List<Consumo> consumos = new ArrayList<>();

        Estadia(Reservacion r, Obligatorio h, LocalDate in) { this.reservacion = r; this.habitacion = h; this.checkIn = in; }

        void agregarConsumo(Adicional s, int qty) { consumos.add(new Consumo(s, qty)); }

        double totalServicios() {
            return consumos.stream().mapToDouble(Consumo::subtotal).sum();
        }
    }

    private static class Factura {
        LocalDate fecha;
        String clienteDni;
        int habitacionNumero;
        double costoHabitacion;
        double costoServicios;
        double total;

        Factura(LocalDate fecha, String dni, int habNum, double costHab, double costServ) {
            this.fecha = fecha; this.clienteDni = dni; this.habitacionNumero = habNum;
            this.costoHabitacion = costHab; this.costoServicios = costServ; this.total = costHab + costServ;
        }

        @Override
        public String toString() {
            return String.format("%s | DNI:%s | Hab:%d | Hab: S/.%.2f | Serv: S/.%.2f | Total: S/.2f",
                    fecha, clienteDni, habitacionNumero, costoHabitacion, costoServicios, total);
        }
    }

    // Public DTOs para uso en GUI (Controller.ReservaDto, etc.)
    public static class ReservaDto {
        public int id;
        public Cliente cliente;
        public LocalDate desde;
        public LocalDate hasta;
        public String tipo;
        public Obligatorio habitacion;
        public boolean active;

        @Override
        public String toString() {
            return String.format("ID:%d | Cliente:%s | %s -> %s | Tipo:%s | Hab:%s | Act:%s",
                    id, cliente.getFullName(), desde, hasta, tipo, (habitacion==null?"-":habitacion.getNumero()), active);
        }
    }

    public static class EstadiaDto {
        public ReservaDto reserva;
        public Obligatorio habitacion;
        public LocalDate checkIn;
    }

    public static class ConsumoDto {
        public Adicional servicio;
        public int qty;
        public double subtotal() { return servicio.getPrecio() * qty; }
        @Override public String toString(){ return servicio.getNombre()+" x"+qty+" = S/."+String.format("%.2f", subtotal()); }
    }

    // -------------------- Métodos de manipulación de reservas (wrappers públicos) --------------------
    public ReservaDto crearReserva(String dniCliente, LocalDate desde, LocalDate hasta, String tipo) {
        Cliente c = clientes.stream().filter(x -> x.getDni().equals(dniCliente)).findFirst().orElse(null);
        if (c == null) return null;
        if (!desde.isBefore(hasta)) return null;
        Reservacion r = new Reservacion(c, desde, hasta, tipo);
        reservaciones.add(r);
        return toDto(r);
    }

    public List<ReservaDto> listarReservas() {
        List<ReservaDto> out = new ArrayList<>();
        for (Reservacion r : reservaciones) out.add(toDto(r));
        return out;
    }

    private ReservaDto toDto(Reservacion r) {
        ReservaDto dto = new ReservaDto();
        dto.id = r.id; dto.cliente = r.cliente; dto.desde = r.desde; dto.hasta = r.hasta;
        dto.tipo = r.tipoHabitacion; dto.habitacion = r.habitacionAsignada; dto.active = r.active;
        return dto;
    }

    // Check-in: asignar habitación específica (por número) a la reservación
    public EstadiaDto checkIn(int reservaId, int numeroHab) {
        Reservacion r = reservaciones.stream().filter(x -> x.id == reservaId).findFirst().orElse(null);
        if (r == null || !r.active) return null;
        Obligatorio h = habitaciones.stream().filter(x -> x.isRoom() && x.getNumero() == numeroHab).findFirst().orElse(null);
        if (h == null) return null;
        if (!"Limpia".equalsIgnoreCase(h.getEstado())) return null;
        // asignar
        r.asignarHabitacion(h);
        h.setEstado("Ocupada");
        Estadia est = new Estadia(r, h, LocalDate.now());
        estadias.add(est);
        return toEstadiaDto(est);
    }

    // Registrar consumo en una estadía por índice (así lo usan las GUIs simples)
    public boolean registrarConsumoEstadia(int indexEstadia, String nombreServicio, int qty) {
        if (indexEstadia < 0 || indexEstadia >= estadias.size()) return false;
        Estadia e = estadias.get(indexEstadia);
        Adicional serv = serviciosAdicionales.stream().filter(x -> x.getNombre().equalsIgnoreCase(nombreServicio)).findFirst().orElse(null);
        if (serv == null) return false;
        e.agregarConsumo(serv, qty);
        return true;
    }

    // Listar estadías (DTOs) para GUIs
    public List<EstadiaDto> listarEstadias() {
        List<EstadiaDto> out = new ArrayList<>();
        for (Estadia e : estadias) {
            out.add(toEstadiaDto(e));
        }
        return out;
    }

    private EstadiaDto toEstadiaDto(Estadia e) {
        EstadiaDto dto = new EstadiaDto();
        dto.reserva = toDto(e.reservacion);
        dto.habitacion = e.habitacion;
        dto.checkIn = e.checkIn;
        return dto;
    }

    // Check-out: por índice de estadía (las GUIs listan estadías y pasan índice)
    public String checkOut(int indexEstadia) {
        if (indexEstadia < 0 || indexEstadia >= estadias.size()) return "Índice inválido";
        Estadia e = estadias.get(indexEstadia);

        long noches = ChronoUnit.DAYS.between(e.reservacion.desde, e.reservacion.hasta);
        if (noches <= 0) noches = 1;

        double costoHab = noches * e.habitacion.getPrecio();
        double costoServ = e.totalServicios();
        Factura f = new Factura(LocalDate.now(), e.reservacion.cliente.getDni(), e.habitacion.getNumero(), costoHab, costoServ);
        facturas.add(f);

        // limpiar/actualizar estado
        e.habitacion.setEstado("Sucia");
        // cancelar reservacion asociada
        e.reservacion.cancelar();
        // remover estadía de activas
        estadias.remove(indexEstadia);

        // devolver resumen factura
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Noches: %d x S/%.2f = S/%.2f%n", noches, e.habitacion.getPrecio(), costoHab));
        sb.append(String.format("Servicios: S/%.2f%n", costoServ));
        sb.append(String.format("TOTAL: S/%.2f%n", f.total));
        return sb.toString();
    }

    // -------------------- Reportes y utilidades --------------------
    public String reporteOcupacion() {
        StringBuilder sb = new StringBuilder();
        for (Obligatorio h : habitaciones) {
            if (h.isRoom()) sb.append(String.format("Hab %d | Tipo:%s | Estado:%s%n", h.getNumero(), h.getTipo(), h.getEstado()));
        }
        return sb.toString();
    }

    public String reporteIngresosPorRango(LocalDate desde, LocalDate hasta) {
        double totalHab = 0, totalServ = 0;
        for (Factura f : facturas) {
            if ((f.fecha.isEqual(desde) || f.fecha.isAfter(desde)) && (f.fecha.isEqual(hasta) || f.fecha.isBefore(hasta))) {
                totalHab += f.costoHabitacion;
                totalServ += f.costoServicios;
            }
        }
        return String.format("Ingresos habitaciones: S/%.2f%nIngresos servicios: S/%.2f%nTotal: S/%.2f%n", totalHab, totalServ, totalHab + totalServ);
    }

    // -------------------- Getters adicionales (si prefieres usar) --------------------
    public List<Reservacion> getReservacionesInternas() { return new ArrayList<>(reservaciones); }
    public List<Estadia> getEstadiasInternas() { return new ArrayList<>(estadias); }
    public List<Factura> getFacturas() { return new ArrayList<>(facturas); }
}
