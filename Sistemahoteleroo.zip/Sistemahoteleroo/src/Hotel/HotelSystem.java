package hotel;

import persona.Cliente;
import persona.Empleado;
import persona.Persona;
import servicio.Adicional;
import servicio.Obligatorio;
import servicio.Servicio;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * HotelSystem: controlador + UI consola.
 *
 * Observaciones de diseño (para respetar tus directrices):
 * - Solo hay clases públicas en packages persona.* y servicio.* (Persona, Empleado, Cliente, Servicio, Obligatorio, Adicional).
 * - Entidades del dominio (Reservación, Estadia, Consumo, Factura) están implementadas como clases internas aquí
 *   para no crear nuevos archivos de clases públicas.
 *
 * Ejecuta en NetBeans: crea packages persona, servicio, hotel, pega los archivos y ejecuta HotelSystem.main.
 */
public class HotelSystem {

    // ----- Repositorios en memoria -----
    private final List<Empleado> empleados = new ArrayList<>();
    private final List<Cliente> clientes = new ArrayList<>();
    private final List<Obligatorio> serviciosObligatorios = new ArrayList<>(); // aquí guardamos habitaciones como Obligatorio
    private final List<Adicional> serviciosAdicionales = new ArrayList<>();
    private final List<Reservacion> reservaciones = new ArrayList<>();
    private final List<Estadia> estadias = new ArrayList<>(); // estadias activas
    private final List<Factura> facturas = new ArrayList<>(); // historico facturas

    private final Scanner sc = new Scanner(System.in);

    // ----- Clases internas del dominio -----
    private static class Reservacion {
        private static int NEXT_ID = 1;
        int id;
        Cliente cliente;
        LocalDate desde;
        LocalDate hasta; // exclusive
        String tipoHabitacion;
        Obligatorio habitacionAsignada; // puede quedar null hasta check-in
        boolean active;

        Reservacion(Cliente c, LocalDate desde, LocalDate hasta, String tipoHabitacion) {
            this.id = NEXT_ID++;
            this.cliente = c;
            this.desde = desde;
            this.hasta = hasta;
            this.tipoHabitacion = tipoHabitacion;
            this.habitacionAsignada = null;
            this.active = true;
        }

        void asignarHabitacion(Obligatorio h) { this.habitacionAsignada = h; }

        void cancelar() { this.active = false; }

        @Override
        public String toString() {
            return String.format("ID:%d | Cliente:%s | %s -> %s | Tipo:%s | HabAsign:%s | Activa:%s",
                    id, cliente.getFullName(), desde, hasta, tipoHabitacion,
                    (habitacionAsignada == null ? "-" : String.valueOf(habitacionAsignada.getNumero())), active);
        }
    }

    private static class Consumo {
        Adicional servicio;
        int cantidad;
        Consumo(Adicional s, int qty) { this.servicio = s; this.cantidad = qty; }
        double total() { return servicio.getPrecio() * cantidad; }
        @Override public String toString() { return servicio.getNombre() + " x" + cantidad + " = S/." + String.format("%.2f", total()); }
    }

    private static class Estadia {
        Reservacion reservacion;
        Obligatorio habitacion;
        LocalDate checkInDate;
        LocalDate checkOutDate; // null hasta checkout
        List<Consumo> consumos = new ArrayList<>();

        Estadia(Reservacion r, Obligatorio h, LocalDate checkIn) {
            this.reservacion = r; this.habitacion = h; this.checkInDate = checkIn; this.checkOutDate = null;
        }

        void agregarConsumo(Adicional s, int qty) { consumos.add(new Consumo(s, qty)); }
        double totalServicios() { return consumos.stream().mapToDouble(Consumo::total).sum(); }

        long nochesHasta(LocalDate outDate) {
            LocalDate end = outDate != null ? outDate : LocalDate.now();
            long n = ChronoUnit.DAYS.between(checkInDate, end);
            return Math.max(1, n); // mínimo 1 noche
        }
    }

    private static class Factura {
        LocalDate fecha;
        String clienteDni;
        int habitacionNumero;
        double costoHabitacion;
        double costoServicios;
        double total;
        Factura(LocalDate fecha, String clienteDni, int habitacionNumero, double costoHabitacion, double costoServicios) {
            this.fecha = fecha; this.clienteDni = clienteDni; this.habitacionNumero = habitacionNumero;
            this.costoHabitacion = costoHabitacion; this.costoServicios = costoServicios;
            this.total = costoHabitacion + costoServicios;
        }
        @Override public String toString() {
            return String.format("%s | DNI:%s | Hab:%d | Hab: S/.%.2f | Serv: S/.%.2f | Total: S/.%.2f",
                    fecha, clienteDni, habitacionNumero, costoHabitacion, costoServicios, total);
        }
    }

    // ----- Inicialización con datos de prueba -----
    private void seed() {
        // Empleados
        empleados.add(new Empleado("11111111", "Admin", "Sistema", "ADMIN", "admin"));
        empleados.add(new Empleado("22222222", "Rosa", "Recep", "RECEP", "recep"));

        // Habitaciones (obligatorio representa habitaciones mediante constructor especial)
        serviciosObligatorios.add(new Obligatorio(101, 2, 100.0, "Simple"));
        serviciosObligatorios.add(new Obligatorio(102, 2, 140.0, "Doble"));
        serviciosObligatorios.add(new Obligatorio(201, 4, 250.0, "Suite"));

        // Servicios adicionales
        serviciosAdicionales.add(new Adicional("Lavandería", 15.0));
        serviciosAdicionales.add(new Adicional("Servicio a la habitación", 20.0));
        serviciosAdicionales.add(new Adicional("Frigobar", 8.0));

        // Clientes
        clientes.add(new Cliente("33333333", "Ana", "Vargas", "999999999"));
        clientes.add(new Cliente("44444444", "Luis", "Gómez", "988888888"));
    }

    // ----- Autenticación -----
    private Empleado autenticar() {
        System.out.println("=== LOGIN ===");
        System.out.print("DNI: "); String dni = sc.nextLine();
        System.out.print("Password: "); String pwd = sc.nextLine();
        for (Empleado e : empleados) if (e.getDni().equals(dni) && e.checkPassword(pwd)) return e;
        System.out.println("Credenciales inválidas.");
        return null;
    }

    // ----- Utilitarios -----
    private Obligatorio encontrarHabitacionPorNumero(int num) {
        for (Obligatorio o : serviciosObligatorios) if (o.isRoom() && o.getNumero() == num) return o;
        return null;
    }

    private Cliente buscarClientePorDni(String dni) {
        for (Cliente c : clientes) if (c.getDni().equals(dni)) return c;
        return null;
    }

    private Reservacion buscarReservacionPorId(int id) {
        for (Reservacion r : reservaciones) if (r.id == id) return r;
        return null;
    }

    // ----- Funciones: Empleado ADMIN -----
    private void crearEmpleado() {
        System.out.println("--- Crear Empleado ---");
        System.out.print("DNI: "); String dni = sc.nextLine();
        System.out.print("Nombres: "); String nom = sc.nextLine();
        System.out.print("Apellidos: "); String ape = sc.nextLine();
        System.out.print("Rol (ADMIN/RECEP): "); String rol = sc.nextLine().toUpperCase();
        System.out.print("Password: "); String pwd = sc.nextLine();
        empleados.add(new Empleado(dni, nom, ape, rol, pwd));
        System.out.println("Empleado creado.");
    }

    private void listarEmpleados() {
        System.out.println("--- Empleados ---");
        for (Empleado e : empleados) System.out.println(e);
    }

    private void eliminarEmpleado() {
        System.out.print("DNI empleado a eliminar: "); String dni = sc.nextLine();
        empleados.removeIf(e -> e.getDni().equals(dni));
        System.out.println("Si existía, se ha eliminado.");
    }

    // ----- Funciones: Habitaciones (Obligatorio actúa como habitación) -----
    private void crearHabitacion() {
        System.out.println("--- Crear Habitación ---");
        System.out.print("Número: "); int num = Integer.parseInt(sc.nextLine());
        System.out.print("Capacidad: "); int cap = Integer.parseInt(sc.nextLine());
        System.out.print("Precio por noche: "); double pre = Double.parseDouble(sc.nextLine());
        System.out.print("Tipo (Simple/Doble/Suite): "); String tipo = sc.nextLine();
        serviciosObligatorios.add(new Obligatorio(num, cap, pre, tipo));
        System.out.println("Habitación creada.");
    }

    private void listarHabitaciones() {
        System.out.println("--- Habitaciones ---");
        for (Obligatorio o : serviciosObligatorios) if (o.isRoom()) System.out.println(o);
    }

    private void modificarEstadoHabitacion() {
        System.out.print("Número hab: "); int num = Integer.parseInt(sc.nextLine());
        Obligatorio h = encontrarHabitacionPorNumero(num);
        if (h == null) { System.out.println("No existe."); return; }
        System.out.print("Nuevo estado (Limpia/Ocupada/Sucia): "); String st = sc.nextLine();
        h.setEstado(st); System.out.println("Estado cambiado.");
    }

    private void eliminarHabitacion() {
        System.out.print("Número hab a eliminar: "); int num = Integer.parseInt(sc.nextLine());
        serviciosObligatorios.removeIf(o -> o.isRoom() && o.getNumero() == num);
        System.out.println("Si existía, se eliminó.");
    }

    // ----- Funciones: Servicios Adicionales (ADMIN) -----
    private void crearServicioAdicional() {
        System.out.println("--- Crear Servicio Adicional ---");
        System.out.print("Nombre: "); String n = sc.nextLine();
        System.out.print("Precio: "); double p = Double.parseDouble(sc.nextLine());
        serviciosAdicionales.add(new Adicional(n, p));
        System.out.println("Servicio adicional creado.");
    }

    private void listarServiciosAdicionales() {
        System.out.println("--- Servicios Adicionales ---");
        for (Adicional a : serviciosAdicionales) System.out.println(a);
    }

    private void eliminarServicioAdicional() {
        System.out.print("Nombre del servicio a eliminar: "); String n = sc.nextLine();
        serviciosAdicionales.removeIf(s -> s.getNombre().equalsIgnoreCase(n));
        System.out.println("Si existía, se eliminó.");
    }

    // ----- Funciones: Clientes (Recepcionista) -----
    private void crearCliente() {
        System.out.println("--- Crear Cliente ---");
        System.out.print("DNI: "); String dni = sc.nextLine();
        System.out.print("Nombres: "); String nom = sc.nextLine();
        System.out.print("Apellidos: "); String ape = sc.nextLine();
        System.out.print("Contacto: "); String cont = sc.nextLine();
        clientes.add(new Cliente(dni, nom, ape, cont));
        System.out.println("Cliente creado.");
    }

    private void listarClientes() {
        System.out.println("--- Clientes ---");
        for (Cliente c : clientes) System.out.println(c);
    }

    private void eliminarCliente() {
        System.out.print("DNI cliente a eliminar: "); String dni = sc.nextLine();
        clientes.removeIf(c -> c.getDni().equals(dni));
        System.out.println("Si existía, se eliminó.");
    }

    // ----- Reservaciones (Recepcionista) -----
    private boolean disponibilidadPorTipo(String tipo, LocalDate desde, LocalDate hasta) {
        long totalTipo = serviciosObligatorios.stream().filter(o -> o.isRoom() && o.getTipo().equalsIgnoreCase(tipo)).count();
        if (totalTipo == 0) return false;

        long ocupadas = 0;
        // contamos reservaciones activas que se solapan
        for (Reservacion r : reservaciones) {
            if (!r.active) continue;
            if (!r.tipoHabitacion.equalsIgnoreCase(tipo)) continue;
            if (datesOverlap(desde, hasta, r.desde, r.hasta)) ocupadas++;
        }
        // contamos estadias activas que ocupan habitaciones de ese tipo
        for (Estadia e : estadias) {
            if (!e.habitacion.getTipo().equalsIgnoreCase(tipo)) continue;
            // usamos rango de la reservacion asociada si existe
            if (e.reservacion != null && datesOverlap(desde, hasta, e.reservacion.desde, e.reservacion.hasta)) ocupadas++;
            else ocupadas++;
        }
        return ocupadas < totalTipo;
    }

    private boolean datesOverlap(LocalDate a1, LocalDate a2, LocalDate b1, LocalDate b2) {
        return a1.isBefore(b2) && b1.isBefore(a2);
    }

    private void crearReservacion() {
        System.out.println("--- Crear Reservación ---");
        System.out.print("DNI cliente: "); String dni = sc.nextLine();
        Cliente c = buscarClientePorDni(dni);
        if (c == null) { System.out.println("Cliente no existe. Regístralo primero."); return; }
        System.out.print("Fecha ingreso (YYYY-MM-DD): "); LocalDate desde = LocalDate.parse(sc.nextLine());
        System.out.print("Fecha salida (YYYY-MM-DD): "); LocalDate hasta = LocalDate.parse(sc.nextLine());
        if (!desde.isBefore(hasta)) { System.out.println("Fechas inválidas."); return; }
        System.out.print("Tipo habitación (Simple/Doble/Suite): "); String tipo = sc.nextLine();

        if (!disponibilidadPorTipo(tipo, desde, hasta)) { System.out.println("No disponible para esas fechas."); return; }

        Reservacion r = new Reservacion(c, desde, hasta, tipo);
        reservaciones.add(r);
        System.out.println("Reservación creada: ID " + r.id);
    }

    private void listarReservaciones() {
        System.out.println("--- Reservaciones ---");
        for (Reservacion r : reservaciones) System.out.println(r);
    }

    private Reservacion obtenerReservacionPorIdPrompt() {
        System.out.print("ID reservación: "); int id = Integer.parseInt(sc.nextLine());
        return buscarReservacionPorId(id);
    }

    // ----- Check-in / Check-out -----
    private void checkIn() {
        System.out.println("--- Check-in ---");
        listarReservaciones();
        Reservacion r = obtenerReservacionPorIdPrompt();
        if (r == null) { System.out.println("Reservación no encontrada."); return; }
        if (!r.active) { System.out.println("Reservación no activa."); return; }
        System.out.print("Número de habitación a asignar: "); int num = Integer.parseInt(sc.nextLine());
        Obligatorio h = encontrarHabitacionPorNumero(num);
        if (h == null) { System.out.println("Hab no existe."); return; }
        if (!h.getTipo().equalsIgnoreCase(r.tipoHabitacion)) { System.out.println("Tipo no coincide."); return; }
        if (!h.getEstado().equalsIgnoreCase("Limpia")) { System.out.println("La habitación debe estar Limpia."); return; }

        // asignar
        r.asignarHabitacion(h);
        h.setEstado("Ocupada");
        Estadia est = new Estadia(r, h, LocalDate.now());
        estadias.add(est);
        System.out.println("Check-in completado.");
    }

    private void checkOut() {
        System.out.println("--- Check-out ---");
        if (estadias.isEmpty()) { System.out.println("No hay estadías activas."); return; }
        // listar estadías con índice
        for (int i = 0; i < estadias.size(); i++) {
            Estadia e = estadias.get(i);
            System.out.printf("%d) Cliente:%s | Hab:%d | Ingreso:%s%n", i, e.reservacion.cliente.getFullName(), e.habitacion.getNumero(), e.checkInDate);
        }
        System.out.print("Índice de estadía a check-out: "); int idx = Integer.parseInt(sc.nextLine());
        if (idx < 0 || idx >= estadias.size()) { System.out.println("Índice inválido."); return; }
        Estadia est = estadias.get(idx);

        // calcular noches usando reservacion si existe, sino usar noches entre checkIn y hoy
        long noches;
        if (est.reservacion != null) {
            noches = ChronoUnit.DAYS.between(est.reservacion.desde, est.reservacion.hasta);
            if (noches <= 0) noches = 1;
            est.reservacion.cancelar();
        } else {
            noches = est.nochesHasta(LocalDate.now());
        }

        double costoHab = noches * est.habitacion.getPrecio();
        double costoServ = est.totalServicios();
        Factura f = new Factura(LocalDate.now(), est.reservacion.cliente.getDni(), est.habitacion.getNumero(), costoHab, costoServ);
        facturas.add(f);

        // marcar habitación sucia y eliminar estadía activa
        est.habitacion.setEstado("Sucia");
        estadias.remove(idx);

        System.out.println("Check-out realizado. Factura:");
        System.out.printf("Noches: %d x S/%.2f = S/%.2f%n", noches, est.habitacion.getPrecio(), costoHab);
        System.out.printf("Servicios: S/%.2f%n", costoServ);
        System.out.printf("Total: S/%.2f%n", f.total);
    }

    // ----- Consumos -----
    private void registrarConsumo() {
        System.out.println("--- Registrar Consumo ---");
        if (estadias.isEmpty()) { System.out.println("No hay estadías activas."); return; }
        for (int i = 0; i < estadias.size(); i++) {
            Estadia e = estadias.get(i);
            System.out.printf("%d) Cliente:%s | Hab:%d%n", i, e.reservacion.cliente.getFullName(), e.habitacion.getNumero());
        }
        System.out.print("Índice estadía: "); int idx = Integer.parseInt(sc.nextLine());
        if (idx < 0 || idx >= estadias.size()) { System.out.println("Índice inválido."); return; }
        Estadia est = estadias.get(idx);

        listarServiciosAdicionales();
        System.out.print("Nombre servicio: "); String nombre = sc.nextLine();
        Adicional serv = null;
        for (Adicional a : serviciosAdicionales) if (a.getNombre().equalsIgnoreCase(nombre)) { serv = a; break; }
        if (serv == null) { System.out.println("Servicio no existe."); return; }
        System.out.print("Cantidad: "); int qty = Integer.parseInt(sc.nextLine());
        est.agregarConsumo(serv, qty);
        System.out.println("Consumo registrado.");
    }

    // ----- Reportes -----
    private void reporteOcupacion() {
        System.out.println("--- Reporte de ocupación ---");
        for (Obligatorio o : serviciosObligatorios) if (o.isRoom()) System.out.printf("Hab %d | Tipo:%s | Estado:%s%n", o.getNumero(), o.getTipo(), o.getEstado());
    }

    private void reporteIngresos() {
        System.out.println("--- Reporte de ingresos por rango ---");
        System.out.print("Fecha inicio (YYYY-MM-DD): "); LocalDate desde = LocalDate.parse(sc.nextLine());
        System.out.print("Fecha fin (YYYY-MM-DD): "); LocalDate hasta = LocalDate.parse(sc.nextLine());

        double totalHab = 0, totalServ = 0;
        for (Factura f : facturas) {
            if ((f.fecha.isEqual(desde) || f.fecha.isAfter(desde)) && (f.fecha.isEqual(hasta) || f.fecha.isBefore(hasta))) {
                totalHab += f.costoHabitacion;
                totalServ += f.costoServicios;
            }
        }
        System.out.printf("Ingresos habitaciones: S/%.2f%nIngresos servicios: S/%.2f%nTotal: S/%.2f%n", totalHab, totalServ, totalHab + totalServ);
    }

    // ----- Menús consola (opción 1: menú clásico) -----
    private void menuAdmin(Empleado admin) {
        boolean salir = false;
        while (!salir) {
            System.out.println("\n--- Menu Administrador ---");
            System.out.println("1) Empleados (Crear/Listar/Eliminar)");
            System.out.println("2) Habitaciones (Crear/Listar/Modificar Estado/Eliminar)");
            System.out.println("3) Servicios adicionales (Crear/Listar/Eliminar)");
            System.out.println("4) Reporte ocupación");
            System.out.println("5) Reporte ingresos");
            System.out.println("0) Cerrar sesión");
            System.out.print("Opción: "); String opt = sc.nextLine();
            switch (opt) {
                case "1":
                    System.out.println("a) Crear  b) Listar  c) Eliminar");
                    String s1 = sc.nextLine();
                    if (s1.equalsIgnoreCase("a")) crearEmpleado();
                    else if (s1.equalsIgnoreCase("b")) listarEmpleados();
                    else if (s1.equalsIgnoreCase("c")) eliminarEmpleado();
                    break;
                case "2":
                    System.out.println("a) Crear  b) Listar  c) Modificar Estado  d) Eliminar");
                    String s2 = sc.nextLine();
                    if (s2.equalsIgnoreCase("a")) crearHabitacion();
                    else if (s2.equalsIgnoreCase("b")) listarHabitaciones();
                    else if (s2.equalsIgnoreCase("c")) modificarEstadoHabitacion();
                    else if (s2.equalsIgnoreCase("d")) eliminarHabitacion();
                    break;
                case "3":
                    System.out.println("a) Crear  b) Listar  c) Eliminar");
                    String s3 = sc.nextLine();
                    if (s3.equalsIgnoreCase("a")) crearServicioAdicional();
                    else if (s3.equalsIgnoreCase("b")) listarServiciosAdicionales();
                    else if (s3.equalsIgnoreCase("c")) eliminarServicioAdicional();
                    break;
                case "4": reporteOcupacion(); break;
                case "5": reporteIngresos(); break;
                case "0": salir = true; break;
                default: System.out.println("Opción inválida.");
            }
        }
    }

    private void menuRecepcionista(Empleado recep) {
        boolean salir = false;
        while (!salir) {
            System.out.println("\n--- Menu Recepcionista ---");
            System.out.println("1) Clientes (Crear/Listar/Eliminar)");
            System.out.println("2) Reservas (Crear/Listar)");
            System.out.println("3) Check-in");
            System.out.println("4) Check-out");
            System.out.println("5) Registrar consumo");
            System.out.println("6) Listar estadías activas");
            System.out.println("0) Cerrar sesión");
            System.out.print("Opción: "); String opt = sc.nextLine();
            switch (opt) {
                case "1":
                    System.out.println("a) Crear  b) Listar  c) Eliminar");
                    String s1 = sc.nextLine();
                    if (s1.equalsIgnoreCase("a")) crearCliente();
                    else if (s1.equalsIgnoreCase("b")) listarClientes();
                    else if (s1.equalsIgnoreCase("c")) eliminarCliente();
                    break;
                case "2":
                    System.out.println("a) Crear  b) Listar");
                    String s2 = sc.nextLine();
                    if (s2.equalsIgnoreCase("a")) crearReservacion();
                    else if (s2.equalsIgnoreCase("b")) listarReservaciones();
                    break;
                case "3": checkIn(); break;
                case "4": checkOut(); break;
                case "5": registrarConsumo(); break;
                case "6":
                    System.out.println("Estadías activas:");
                    for (Estadia e : estadias) System.out.printf("Cliente:%s | Hab:%d | Ingreso:%s | Consumos:%d%n",
                            e.reservacion.cliente.getFullName(), e.habitacion.getNumero(), e.checkInDate, e.consumos.size());
                    break;
                case "0": salir = true; break;
                default: System.out.println("Opción inválida.");
            }
        }
    }

    // ----- Ejecución principal -----
    public void run() {
        seed();
        boolean terminar = false;
        while (!terminar) {
            Empleado e = autenticar();
            if (e == null) {
                System.out.print("Intentar login de nuevo? (s/n): ");
                String r = sc.nextLine().toLowerCase();
                if (!r.equals("s")) break;
                else continue;
            }
            if ("ADMIN".equalsIgnoreCase(e.getRol())) menuAdmin(e);
            else if ("RECEP".equalsIgnoreCase(e.getRol())) menuRecepcionista(e);
            else System.out.println("Rol no reconocido, logout automático.");

            System.out.print("Salir del sistema por completo? (s/n): ");
            if (sc.nextLine().equalsIgnoreCase("s")) terminar = true;
        }
        System.out.println("Saliendo. Adiós.");
        sc.close();
    }

    public static void main(String[] args) {
        new HotelSystem().run();
    }
}