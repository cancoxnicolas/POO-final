package gui;

import hotel.Controller;
import persona.Cliente;

import javax.swing.*;
import java.awt.*;

public class ClientesGUI extends JFrame {
    private final Controller controller;
    private final JTextArea area = new JTextArea();

    public ClientesGUI(Controller controller) {
        this.controller = controller;
        initUI();
    }

    private void initUI() {
        setTitle("Clientes");
        setSize(520,420);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel top = new JPanel();
        JButton btnCrear = new JButton("Crear");
        JButton btnListar = new JButton("Listar");
        top.add(btnCrear); top.add(btnListar);
        add(top, BorderLayout.NORTH);

        area.setEditable(false);
        add(new JScrollPane(area), BorderLayout.CENTER);

        btnCrear.addActionListener(a -> {
            String dni = JOptionPane.showInputDialog(this,"DNI:");
            String nom = JOptionPane.showInputDialog(this,"Nombres:");
            String ape = JOptionPane.showInputDialog(this,"Apellidos:");
            String cont = JOptionPane.showInputDialog(this,"Contacto:");
            if (dni!=null && nom!=null) {
                controller.crearCliente(dni, nom, ape, cont);
                JOptionPane.showMessageDialog(this,"Cliente creado.");
            }
        });

        btnListar.addActionListener(a -> {
            StringBuilder sb = new StringBuilder();
            for (Cliente c : controller.listarClientes()) sb.append(c).append("\n");
            area.setText(sb.toString());
        });
    }
}
