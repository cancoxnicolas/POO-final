package gui;

import hotel.Controller;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class ReservasGUI extends JFrame {
    private final Controller controller;
    private final JTextArea area = new JTextArea();

    public ReservasGUI(Controller controller) {
        this.controller = controller;
        initUI();
    }

    private void initUI() {
        setTitle("Reservas");
        setSize(600,400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel top = new JPanel();
        JButton btnCrear = new JButton("Crear");
        JButton btnListar = new JButton("Listar");
        top.add(btnCrear); top.add(btnListar);
        add(top, BorderLayout.NORTH);

        area.setEditable(false);
        add(new JScrollPane(area), BorderLayout.CENTER);

        btnCrear.addActionListener(a -> {
            try {
                String dni = JOptionPane.showInputDialog(this,"DNI cliente:");
                String desde = JOptionPane.showInputDialog(this,"Fecha desde (YYYY-MM-DD):");
                String hasta = JOptionPane.showInputDialog(this,"Fecha hasta (YYYY-MM-DD):");
                String tipo = JOptionPane.showInputDialog(this,"Tipo habitación:");
                Controller.ReservaDto r = controller.crearReserva(dni, LocalDate.parse(desde), LocalDate.parse(hasta), tipo);
                if (r==null) JOptionPane.showMessageDialog(this,"Error: cliente no existe o fechas inválidas");
                else JOptionPane.showMessageDialog(this,"Reservación creada: ID " + r.id);
            } catch(Exception ex){ JOptionPane.showMessageDialog(this,"Entrada inválida"); }
        });

        btnListar.addActionListener(a -> {
            StringBuilder sb = new StringBuilder();
            for (Controller.ReservaDto r: controller.listarReservas()) sb.append(r).append("\n");
            area.setText(sb.toString());
        });
    }
}
