package gui;

import hotel.Controller;
import persona.Empleado;

import javax.swing.*;
import java.awt.*;

public class MenuRecepGUI extends JFrame {
    private final Controller controller;
    private final Empleado user;

    public MenuRecepGUI(Controller controller, Empleado user) {
        this.controller = controller;
        this.user = user;
        initUI();
    }

    private void initUI() {
        setTitle("Menu Recepcionista - " + user.getFullName());
        setSize(900, 320);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        JButton btnClientes = new JButton("Clientes");
        JButton btnReservas = new JButton("Reservas");
        JButton btnCheckIn = new JButton("Check-in");
        JButton btnCheckOut = new JButton("Check-out");
        JButton btnConsumos = new JButton("Registrar Consumo");
        JButton btnListEst = new JButton("Listar Estadías");
        JButton btnLogout = new JButton("Cerrar sesión");

        p.add(btnClientes); p.add(btnReservas); p.add(btnCheckIn); p.add(btnCheckOut);
        p.add(btnConsumos); p.add(btnListEst); p.add(btnLogout);
        add(p);

        btnClientes.addActionListener(a -> new ClientesGUI(controller).setVisible(true));
        btnReservas.addActionListener(a -> new ReservasGUI(controller).setVisible(true));
        btnCheckIn.addActionListener(a -> new CheckInGUI(controller).setVisible(true));
        btnCheckOut.addActionListener(a -> new CheckOutGUI(controller).setVisible(true));
        btnConsumos.addActionListener(a -> new ConsumosGUI(controller).setVisible(true));

        btnListEst.addActionListener(a -> {
            StringBuilder sb = new StringBuilder();
            int i = 0;
            for (Controller.EstadiaDto e : controller.listarEstadias()) {
                sb.append(i++).append(") ").append(e.reserva.cliente.getFullName()).append(" | Hab: ").append(e.habitacion.getNumero()).append("\n");
            }
            JOptionPane.showMessageDialog(this, sb.length()==0?"No hay estadías":sb.toString());
        });

        btnLogout.addActionListener(a -> {
            dispose();
            new MainWindow().setVisible(true);
        });
    }
}
