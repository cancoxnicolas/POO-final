package gui;

import hotel.Controller;
import persona.Empleado;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MainWindow extends JFrame {
    private final Controller controller;
    private final JTextField txtUser = new JTextField(12);
    private final JPasswordField txtPass = new JPasswordField(12);
    private final JLabel lblMsg = new JLabel(" ");

    public MainWindow() {
        controller = new Controller();
        initUI();
    }

    private void initUI() {
        setTitle("Sistema Hotelero - Login");
        setSize(480, 260);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel login = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6,6,6,6);

        c.gridx=0; c.gridy=0; login.add(new JLabel("DNI:"), c);
        c.gridx=1; login.add(txtUser, c);

        c.gridx=0; c.gridy=1; login.add(new JLabel("Password:"), c);
        c.gridx=1; login.add(txtPass, c);

        JButton btnLogin = new JButton("Iniciar Sesión");
        c.gridx=1; c.gridy=2; login.add(btnLogin, c);
        c.gridx=1; c.gridy=3; login.add(lblMsg, c);

        btnLogin.addActionListener((ActionEvent e) -> {
            String dni = txtUser.getText().trim();
            String pwd = new String(txtPass.getPassword());
            Empleado emp = controller.login(dni, pwd);
            if (emp == null) {
                lblMsg.setText("Credenciales inválidas");
            } else {
                lblMsg.setText("Bienvenido " + emp.getFullName());
                if ("ADMIN".equalsIgnoreCase(emp.getRol())) {
                    new MenuAdminGUI(controller, emp).setVisible(true);
                } else {
                    new MenuRecepGUI(controller, emp).setVisible(true);
                }
                dispose();
            }
        });

        add(login);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainWindow().setVisible(true));
    }
}
