package gui;

import hotel.Controller;

import javax.swing.*;

public class CheckOutGUI extends JFrame {
    private final Controller controller;

    public CheckOutGUI(Controller controller) {
        this.controller = controller;
        initUI();
    }

    private void initUI() {
        setTitle("Check-out");
        setSize(520,220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JButton btn = new JButton("Realizar Check-out (usar índice de Listar Estadías)");
        btn.addActionListener(a -> {
            try {
                int idx = Integer.parseInt(JOptionPane.showInputDialog(this,"Índice de estadía:"));
                String factura = controller.checkOut(idx);
                JOptionPane.showMessageDialog(this, factura);
            } catch(Exception ex){ JOptionPane.showMessageDialog(this,"Entrada inválida"); }
        });
        add(btn);
    }
}
