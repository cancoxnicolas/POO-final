package gui;

import hotel.Controller;
import servicio.Obligatorio;

import javax.swing.*;
import java.awt.*;

public class HabitacionesGUI extends JFrame {
    private final Controller controller;
    private final JTextArea area = new JTextArea();

    public HabitacionesGUI(Controller controller) {
        this.controller = controller;
        initUI();
    }

    private void initUI() {
        setTitle("Gestión de Habitaciones");
        setSize(600, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(6,6));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnCrear = new JButton("Crear");
        JButton btnListar = new JButton("Listar");
        JButton btnCambiarEstado = new JButton("Cambiar Estado");
        top.add(btnCrear); top.add(btnListar); top.add(btnCambiarEstado);
        add(top, BorderLayout.NORTH);

        area.setEditable(false);
        add(new JScrollPane(area), BorderLayout.CENTER);

        btnCrear.addActionListener(a -> {
            try {
                int num = Integer.parseInt(JOptionPane.showInputDialog(this, "Número:"));
                int cap = Integer.parseInt(JOptionPane.showInputDialog(this, "Capacidad:"));
                double precio = Double.parseDouble(JOptionPane.showInputDialog(this, "Precio noche:"));
                String tipo = JOptionPane.showInputDialog(this, "Tipo (Simple/Doble/Suite):");
                controller.crearHabitacion(num, cap, precio, tipo);
                JOptionPane.showMessageDialog(this, "Habitación creada.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Entrada inválida");
            }
        });

        btnListar.addActionListener(a -> area.setText(controller.listarHabitaciones()));

        btnCambiarEstado.addActionListener(a -> {
            try {
                int num = Integer.parseInt(JOptionPane.showInputDialog(this,"Número hab:"));
                String nuevo = JOptionPane.showInputDialog(this,"Estado (Limpia/Ocupada/Sucia):");
                boolean found = false;
                for (Obligatorio h : controller.listarHabitacionesList()) {
                    if (h.getNumero() == num) { h.setEstado(nuevo); found = true; break; }
                }
                JOptionPane.showMessageDialog(this, found? "Estado cambiado." : "Habitación no encontrada.");
            } catch (Exception ex) { JOptionPane.showMessageDialog(this,"Error"); }
        });
    }
}
