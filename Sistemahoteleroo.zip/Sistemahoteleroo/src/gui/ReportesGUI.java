package gui;

import hotel.Controller;

import javax.swing.*;
import java.awt.*;

public class ReportesGUI extends JFrame {
    private final Controller controller;
    private final JTextArea area = new JTextArea();

    public ReportesGUI(Controller controller) {
        this.controller = controller;
        initUI();
    }

    private void initUI() {
        setTitle("Reportes");
        setSize(600,300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel top = new JPanel();
        JButton btnOc = new JButton("Reporte Ocupación");
        top.add(btnOc);
        add(top, BorderLayout.NORTH);

        area.setEditable(false);
        add(new JScrollPane(area), BorderLayout.CENTER);

        btnOc.addActionListener(a -> area.setText(controller.reporteOcupacion()));
    }
}
