package gui;

import hotel.Controller;

import javax.swing.*;

public class ConsumosGUI extends JFrame {
    private final Controller controller;

    public ConsumosGUI(Controller controller) {
        this.controller = controller;
        initUI();
    }

    private void initUI() {
        setTitle("Registrar Consumo");
        setSize(450,220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JButton btn = new JButton("Registrar Consumo");
        btn.addActionListener(a -> {
            try {
                int idx = Integer.parseInt(JOptionPane.showInputDialog(this,"Índice estadía:"));
                String serv = JOptionPane.showInputDialog(this,"Nombre servicio (exacto):");
                int qty = Integer.parseInt(JOptionPane.showInputDialog(this,"Cantidad:"));
                boolean ok = controller.registrarConsumoEstadia(idx, serv, qty);
                JOptionPane.showMessageDialog(this, ok? "Consumo agregado" : "Error");
            } catch(Exception ex){ JOptionPane.showMessageDialog(this,"Entrada inválida"); }
        });
        add(btn);
    }
}
