package gui;

import hotel.Controller;

import javax.swing.*;

public class CheckInGUI extends JFrame {
    private final Controller controller;

    public CheckInGUI(Controller controller) {
        this.controller = controller;
        initUI();
    }

    private void initUI() {
        setTitle("Check-in");
        setSize(420,160);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JButton btn = new JButton("Realizar Check-in");
        btn.addActionListener(a -> {
            try {
                int id = Integer.parseInt(JOptionPane.showInputDialog(this,"ID reservación:"));
                int hab = Integer.parseInt(JOptionPane.showInputDialog(this,"Número habitación a asignar:"));
                Controller.EstadiaDto est = controller.checkIn(id, hab);
                JOptionPane.showMessageDialog(this, est==null? "Error en check-in" : "Check-in OK");
            } catch(Exception ex){ JOptionPane.showMessageDialog(this,"Entrada inválida"); }
        });
        add(btn);
    }
}
