package gui;

import hotel.Controller;
import persona.Empleado;

import javax.swing.*;
import java.awt.*;

public class MenuAdminGUI extends JFrame {
    private final Controller controller;
    private final Empleado user;

    public MenuAdminGUI(Controller controller, Empleado user) {
        this.controller = controller;
        this.user = user;
        initUI();
    }

    private void initUI() {
        setTitle("Menu Admin - " + user.getFullName());
        setSize(700, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        JButton btnEmpleados = new JButton("Empleados");
        JButton btnHabit = new JButton("Habitaciones");
        JButton btnServ = new JButton("Servicios Adicionales");
        JButton btnReport = new JButton("Reportes");
        JButton btnLogout = new JButton("Cerrar sesión");

        p.add(btnEmpleados); p.add(btnHabit); p.add(btnServ); p.add(btnReport); p.add(btnLogout);
        add(p);

        btnEmpleados.addActionListener(a -> {
            StringBuilder sb = new StringBuilder();
            for (var e : controller.listarEmpleados()) sb.append(e).append("\n");
            JOptionPane.showMessageDialog(this, sb.length()==0?"No hay empleados":sb.toString());
        });

        btnHabit.addActionListener(a -> new HabitacionesGUI(controller).setVisible(true));

        btnServ.addActionListener(a -> {
            String s = controller.listarServiciosStr();
            JOptionPane.showMessageDialog(this, s.length()==0?"No hay servicios":s);
        });

        btnReport.addActionListener(a -> new ReportesGUI(controller).setVisible(true));

        btnLogout.addActionListener(a -> {
            dispose();
            new MainWindow().setVisible(true);
        });
    }
}
