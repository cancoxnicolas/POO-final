package servicio;

// Clase base Servicio
public class Servicio {
    protected String nombre;
    protected double precio;

    public Servicio(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }

    @Override
    public String toString() {
        return nombre + " - S/." + String.format("%.2f", precio);
    }
}
